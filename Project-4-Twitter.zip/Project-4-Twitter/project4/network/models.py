from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    followers=models.ManyToManyField("self",related_name="following",blank=True,symmetrical=False) 
    
    def number_of_followers(self):
        return len(self.followers.all())

    def number_of_following(self):
        return len(self.following.all())

class Profile(models.Model):
    target = models.ForeignKey('User', on_delete=models.CASCADE, related_name='folowers')
    follower = models.ForeignKey('User', on_delete=models.CASCADE, related_name='targets')

class Post(models.Model):
    creater=models.ForeignKey('User', on_delete=models.CASCADE,related_name="author")
    content=models.TextField()
    datetime=models.DateTimeField(auto_now=True)
    liked = models.ManyToManyField('User', default=None, blank=True, related_name='post_likes')

    def number_of_likes(self):
        return len(self.like.all)
    

class Like(models.Model):
    user = models.ForeignKey('User', on_delete=models.CASCADE)
    post = models.ForeignKey('Post', on_delete=models.CASCADE)


    def __str__(self):
        return str(self.post)



# symmetrical=False
# When Django processes this model, it identifies that it has a ManyToManyField on itself, and as a result, it doesn’t add a person_set attribute to the Person class. 
# Instead, the ManyToManyField is assumed to be symmetrical – that is, if I am your friend, then you are my friend.
# By default, the value of symmetrical is True for Many to Many Field which is a bi-directional relationship.